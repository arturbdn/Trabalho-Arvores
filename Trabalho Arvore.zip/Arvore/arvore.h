
typedef struct arvore Arvore;
Arvore* criarArvore();;
Arvore* insere(Arvore* raiz, int novo);
Arvore* buscar(Arvore* raiz, int valor);
Arvore* remover(Arvore* raiz, int valor);
Arvore* sucessor(Arvore* raiz, Arvore* val);
Arvore* maior(Arvore* raiz);
Arvore* menor(Arvore* raiz);
void imprimir(Arvore* raiz);
int getnum(Arvore* raiz);










