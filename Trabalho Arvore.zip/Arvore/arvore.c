#include "arvore.h"
#include <stdlib.h>
#include <stdio.h>

struct arvore{
	int num;
	Arvore* dir;
	Arvore* esq;
};

Arvore* criarArvore(){
	return NULL;
}

Arvore* insere(Arvore* raiz,int novo){
	
	if(raiz==NULL){
		raiz = (Arvore*) malloc(sizeof(Arvore));
		raiz->num=novo;
		raiz->esq=NULL;
		raiz->dir=NULL;
	}
	else if(novo < raiz->num){
		raiz->esq = insere(raiz->esq,novo);
	}
	else{
		raiz->dir = insere(raiz->dir,novo);
	}
	return raiz;
}

Arvore* buscar(Arvore* raiz,int valor){
	
	if(valor==raiz->num){
		return raiz;
	}
	else if(valor < raiz->num){
		return buscar(raiz->esq,valor);
	}
	else if(valor > raiz->num){
		return buscar(raiz->dir,valor);
	}
	else{
		return raiz;
	}
}

Arvore* menor(Arvore* raiz){
	Arvore* p = raiz;
	while(p->esq != NULL){
		p = p->esq;
	}	
	return p;
}

Arvore* sucessor(Arvore* raiz,Arvore* val){

	if(val->dir != NULL){
		return menor(val->dir);
	}
	Arvore* suc = NULL;
	while(raiz != NULL){
		if(val->num < raiz->num){
			suc = raiz;
			raiz = raiz->esq;
		}
		else if (val->num> raiz->num){
			raiz=raiz->dir;
		}
		else{
			break;
		}
	}
	return suc;
}

Arvore* remover(Arvore* raiz,int valor){
	
	if( raiz == NULL){
		return NULL;
	}
	else if( valor < raiz->num){
		raiz->esq = remover(raiz->esq, valor);
	}
	else if( valor > raiz->num){
		raiz->dir = remover(raiz->dir, valor);
	}
	
	if(raiz->esq == NULL && raiz->dir == NULL){
		free (raiz); 
		raiz = NULL;
	}
		
	else if(raiz->esq == NULL && raiz->dir != NULL){
		Arvore*p = raiz;
		raiz = raiz->dir;
		free (p);
	}
	else if(raiz->esq != NULL && raiz->dir == NULL){
		Arvore*p = raiz;
		raiz = raiz->esq;
		free (p); 
	}
	else if(raiz->esq != NULL && raiz->dir != NULL){
		Arvore* suc = sucessor(raiz,suc);
		raiz->num= suc->num;
		free(suc);
		suc = NULL;
	}
	return raiz;

}

void imprimir(Arvore* raiz){
	if(raiz!=NULL){
		printf("%d\n",raiz->num);
		imprimir(raiz->esq);
		imprimir(raiz->dir);		
	}
}
int getnum(Arvore* raiz){
	return raiz->num;
}

