#include <stdio.h>
#include <stdlib.h>
#include "arvore.h"

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	Arvore* novo=criarArvore();
	int op;
	printf("Menu\n");
	printf("1-inserir\n");
	printf("2-buscar\n");
	printf("3-remover\n");
	printf("4-imprimir\n");
	printf("5-sair\n");
	
	
	
	while(1==1){
		printf("Digite sua opcao: ");
		scanf("%d",&op);
		
		if(op==1){
			novo = insere(novo,15);
			novo = insere(novo,10);
		}
		if(op==2){
			novo = buscar(novo,10);
			imprimir(novo);
		}
		if(op==3){
			novo = remover(novo,10);
			//imprimir(novo);
		}
		if(op==4){
			imprimir(novo);
		}
		if(op==5){
			exit(1);
		}
	}
		
	return 0;
}
